<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
?>
<?php
error_reporting(E_ALL ^ E_NOTICE);
if ($_SESSION["autenticado"]==true) {
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Aplicativo | Página de inicio</title>
  <link rel="shortcut icon" href="assets/img/logo.ico" type="image/x-icon" />
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="assets/bower_components/Ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="assets/bower_components/jvectormap/jquery-jvectormap.css">
  <link rel="stylesheet" href="assets/css/AdminLTE.min.css">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css" />
  <link rel="stylesheet" href="assets/css/skins/_all-skins.min.css">
  <link rel="stylesheet" type="text/css" href="assets/css/codigo.css" />
  <link rel="stylesheet" href="assets/css/skins/skin-blue.min.css">
  <!--<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">este link es el que cambia los iconos-->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <link rel="stylesheet" href="assets/js/jquery-ui/jquery-ui.min.css" />
  <link rel="stylesheet" href="assets/css/style.css" />
  <link rel="stylesheet" href="assets/css/skins/_all-skins.min.css">
  <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
  <script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
  <script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
</head>
<style>
 
   .box
   {
    padding:20px;
    background-color:#fff;
    border:1px solid #ccc;
    border-radius:5px;
    margin-top:25px;
   }
  </style>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    <!-- Logo -->

    <a href="?c=cliente&a=Entrada" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>P</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg">Aplicativo Psicología</span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-envelope-o"></i>
              <span class="label label-success">Aquí el numero que sale arriba de los mensajes</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"> coloque el numero de mensajes que tiene</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                  </li>
                </ul>
              </li>
              <li class="footer"><a href="#">Ver todos los mensajes</a></li>
            </ul>
          </li>
          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <span class="label label-warning">Acá ponga el número de notificaciones que va arriba</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"> coloque el numero de notificaciones acá</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                </ul>
              </li>
              <li class="footer"><a href="#">Ver todo</a></li>
            </ul>
          </li>
          <!-- Tasks: style can be found in dropdown.less -->
          <li class="dropdown tasks-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-flag-o"></i>
              <span class="label label-danger">Acá va el número de tareas que va arriba</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">Aquí van las tareas</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                </ul>
              </li>
              <li class="footer">
                <a href="#">Ver todas las tareas</a>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="assets/img/user8-128x128.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $_SESSION["user"]["nombres"]." ".$_SESSION["user"]["apellidos"]; ?>
              </span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="assets/img/user8-128x128.jpg" class="img-circle" alt="User Image">

                <p>
                  <?php echo $_SESSION["user"]["nombres"]." ".$_SESSION["user"]["apellidos"]; ?>
                  <small><?php  
                  if ($_SESSION['user']['roles_id_rol'] ==4) {
                echo "Administrador";
            }elseif ($_SESSION['user']['roles_id_rol']==3) {
                echo "Asesor Academico";
            }elseif ($_SESSION['user']['roles_id_rol'] ==2) {
                echo "Moderador";
            }elseif ($_SESSION['user']['roles_id_rol'] ==5) {
                echo "Jefe Institucional";
            }elseif ($_SESSION['user']['roles_id_rol'] ==1) {
                echo "Estudiante";
            }elseif ($_SESSION['user']['roles_id_rol'] ==0) {
                echo "Superadministrador";
            }?></small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Perfil</a>
                </div>
                <div class="pull-right">
                  <a href="?c=cliente&a=Index" class="btn btn-default btn-flat">Cerrar Sesión</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
        </ul>
      </div>

    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
 <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="assets/img/user8-128x128.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $_SESSION["user"]["nombres"]." ".$_SESSION["user"]["apellidos"]; ?></p>
          <a><i class="fa fa-circle text-success"></i>
                  <small><?php  
                  if ($_SESSION['user']['roles_id_rol'] ==4) {
                echo "Administrador";
            }elseif ($_SESSION['user']['roles_id_rol']==3) {
                echo "Asesor Academico";
            }elseif ($_SESSION['user']['roles_id_rol'] ==2) {
                echo "Moderador";
            }elseif ($_SESSION['user']['roles_id_rol'] ==5) {
                echo "Jefe Institucional";
            }elseif ($_SESSION['user']['roles_id_rol'] ==1) {
                echo "Estudiante";
            }elseif ($_SESSION['user']['roles_id_rol'] ==0) {
                echo "Superadministrador";
            }?></small>
          </a>
        </div>
      </div>
    </section>

      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">NAVEGACION PRINCIPAL</li>
        <li><a href="?c=cliente&a=Entrada"><i class="fa fa-home "></i> <span>Inicio</span></a></li>
        <li><a href="?c=cliente&a=Inicio"><i class="fa fa-book"></i> <span>Asignación de Roles</span></a></li>
        <li><a href="?c=cliente&a=Procesos"><i class="fa  fa-pie-chart"></i> <span>Procesos</span></a></li>
        <li><a href="?c=cliente&a=Estudiantes"><i class="fa fa-hand-spock-o"></i> <span>Estudiantes</span></a></li>

  </aside>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Aplicativo Psicología
        <small>Version 1.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="?c=cliente&a=Entrada"><i class="fa fa-home"></i> Inicio</a></li>
        <li class="active"><i class="fa fa-hand-spock-o"></i> Estudiante</a></li>
      </ol>
       </section>
    

    <!-- Main content -->
    <section class="content container-fluid">


      <!--------------------------
        | Your Page Content Here |
        -------------------------->
<br>

             <div class="login-box-body">
<h3 class="box-title">Estudiantes</h3>
<div class="box box-danger">
<section class="content-header">

           <nav><ul class="circulos">


<li><a href="http://www.google.com" style="background-color: #3da736" onclick="return false" title="1. Recepción de Documentos: El ESTUDIANTE carga 7 archivos. El MODERADOR revisa los documentos cargados y si todos están correctos, da el aval de continuar. 
" ><img src="https://img.icons8.com/windows/50/0/home.png"></a></li>


<svg height="2" width="120" >
  <line x1="0" y1="-1" x2="200" y2="0" style="stroke:#004165;stroke-width:5"  />
  </svg>
  <li><a href="http://www.google.com"  onclick="return  false" style="background-color: #afa8aaab"  /*style="background-color: #3da736"*/  title="2. Descarga de ARL y Credencial: El MODERADOR carga el ARL del ESTUDIANTE respectivo o multi-carga en un espacio donde se alojan todas las ARL y el ESTUDIANTE lo descarga. El MODERADOR  hace revisión y habilita el siguiente paso. Para la credencial, el MODERADOR sube el formato, el ESTUDIANTE lo descarga y lo llena con las indicaciones dadas. 
"><img src="https://img.icons8.com/dotty/30/000000/desktop-download.png"></a></li>
<svg height="2" width="120">
  <line x1="0" y1="-1" x2="200" y2="0" style="stroke:#004165;stroke-width:5"  />
  </svg>

<li><a href="http://www.google.com"  onclick="return false" false" style="background-color: #afa8aaab"  /*style="background-color: #3da736"*/ title="3. Entrega de Credencial: El ESTUDIANTE carga la CREDENCIAL después de haberla editado digitalmente y espera a que el MODERADOR lo revise y haga firmar de los entes requeridos. El MODERADOR carga nuevamente la credencial que el ESTUDIANTE deberá descargar y presentar junto con el formato de ARL en la institución. El JEFE INSTITUCIONAL y el ASESOR ACADÉMICO pueden revisar esta información del ESTUDIANTE. 
" ><img src="https://img.icons8.com/ios/30/000000/upload-to-ftp.png"></a></li>
<svg height="2" width="120">
  <line x1="0" y1="-1" x2="200" y2="0" style="stroke:#004165;stroke-width:5"  />
  </svg>
  <li><a href="http://www.google.com"  onclick="return false"  false" style="background-color: #afa8aaab"  /*style="background-color: #3da736"*/ title="4. Entrega de Formatos de Inicio de Prácticas: El MODERADOR carga los formatos de inicio de prácticas, que son corregidos y actualizados por este mismo. El ESTUDIANTE los descarga. 
"><img src="https://img.icons8.com/wired/30/000000/folder-invoices.png"></a></li>
<svg height="2" width="120">
  <line x1="0" y1="-1" x2="200" y2="0" style="stroke:#004165;stroke-width:5"  />
  </svg>
<li><a href="#"  onclick="return false" false" style="background-color: #afa8aaab"  /*style="background-color: #3da736"*/ title="5. DOFA y Plan de Trabajo: El ESTUDIANTE carga 2 archivos: El diagnóstico institucional y el plan de trabajo, archivos que son revisados por el JEFE INSTITUCIONAL, el ASESOR ACADÉMICO y el MODERADOR. Estos documentos darán inicio a la Etapa Número 2 del proceso de prácticas.
"><img src="https://img.icons8.com/ios/30/000000/filing-cabinet.png"></a></li>

</ul></nav>
<br /> <br />
 <table>
      
  
  <span><b>1. Documento de Identidad</b></span>   
  <ol>
  <form enctype="multipart/form-data" action="uploader.php" method="POST">
  <input name="uploadedfile" type="file" />
  <input type="submit" value="Subir archivo" /><img src="https://png.icons8.com/ios-glyphs/50/0000/upload-to-ftp.png">
  </form><br>
  </ol>

  
    <span><b>2. Certificado de EPS</b></span>   
    <ol>
  <form enctype="multipart/form-data" action="uploader.php" method="POST">
  <input name="uploadedfile" type="file" />

  <input type="submit" value="Subir archivo" />
  <img src="https://png.icons8.com/ios-glyphs/50/0000/upload-to-ftp.png">
  </form><br>
  </ol>

  

  <span><b> 3. Resivo de Pago de Matricula</b></span> 
  <ol>
  <form enctype="multipart/form-data" action="uploader.php" method="POST">
  <input name="uploadedfile" type="file" />
  <input type="submit" value="Subir archivo" />
  <img src="https://png.icons8.com/ios-glyphs/50/0000/upload-to-ftp.png">
  </form><br>
    </ol>

  <span><b>4. Matricula Academica</b></span>
  <ol>
  <form enctype="multipart/form-data" action="uploader.php" method="POST">
  <input name="uploadedfile" type="file" />
  <input type="submit" value="Subir archivo" /><img src="https://png.icons8.com/ios-glyphs/50/0000/upload-to-ftp.png">
  </form><br>
  </ol>

  <span><b>5. Carnet de Vacunas</b></span>
  <ol>
  <form enctype="multipart/form-data" action="uploader.php" method="POST">
  <input name="uploadedfile" type="file" />
  <input type="submit" value="Subir archivo" />
  <img src="https://png.icons8.com/ios-glyphs/50/0000/upload-to-ftp.png">
  </form><br>
  </ol>


  <span><b>6. Ponderado de Notas</b></span>
  <ol>
  <form enctype="multipart/form-data" action="uploader.php" method="POST">
  <input name="uploadedfile" type="file" />
  <input type="submit" value="Subir archivo" />
  <img src="https://png.icons8.com/ios-glyphs/50/0000/upload-to-ftp.png">
  </form><br>
    </ol>
  
  <span><b>7. Carnet Estudiantil</b></span>
  <ol>
  <form enctype="multipart/form-data" action="uploader.php" method="POST">
  <input name="uploadedfile" type="file" />
  <input type="submit" value="Subir archivo" />
  <img src="https://png.icons8.com/ios-glyphs/50/0000/upload-to-ftp.png">
  </form>
  </ol>
  <a href="index_paso2.php"><input type="submit" value="Guardar"></a>
  
  </table>
   </div>
                </div>

                <!--/.box-header--> 
                <div class="box-body no-padding">
                  <ul class="users-list clearfix">
                    
                  </ul>
                   <!--/.users-list -->
                </div>
              </div>
             <!-- /.box -->
            </div>
            <!-- /.col--> 
          </div>

          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row 
    </section>
     /.content -->
  </div>
</ul></nav></section></div></div>
  <!-- /.content-wrapper -->

  <!-- Main Footer -->
<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.1
    </div>
    <strong>Copyright &copy; 2018 <a href="https://www.ucc.edu.co/">UCC</a>.</strong> Todos los derechos reservados.
  </footer>

   </div>
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->

</script>
<!-- Bootstrap 3.3.7 -->
<script src="assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="assets/js/adminlte.min.js"></script>
<!-- Sparkline -->
<script src="assets/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap  -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- SlimScroll -->
<script src="assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- ChartJS -->
<script src="assets/bower_components/chart.js/Chart.js"></script>

<!-- AdminLTE for demo purposes -->
<script src="assets/js/demo.js"></script>

</body>

<script  src="assets/js/datatable.js"> </script>
</html>
<?php 
}
else{
require_once 'views/error_acceso.html';
require_once 'views/index.html';
}
?>
