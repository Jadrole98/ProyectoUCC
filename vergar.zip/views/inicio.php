<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
?>
<?php
error_reporting(E_ALL ^ E_NOTICE);
if ($_SESSION["autenticado"]==true) {
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Aplicativo | Página de </title>

  <!-- Tell the browser to be responsive to screen width -->
  <link rel="shortcut icon" href="assets/img/logo.ico" type="image/x-icon" />
  
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="assets/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="assets/bower_components/Ionicons/css/ionicons.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="assets/bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="assets/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="assets/css/skins/_all-skins.min.css">
  <link rel='stylesheet' href="assets/css/swiper.min.css">
  <link rel="stylesheet" href="assets/css/slider.css">
  <link rel="stylesheet" href="assets/css/slider1.scss">
  <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    <!-- Logo -->

    <a href="?c=cliente&a=Entrada" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>P</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg">Aplicativo Psicología</span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-envelope-o"></i>
              <span class="label label-success">Aquí el numero que sale arriba de los mensajes</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"> coloque el numero de mensajes que tiene</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                  </li>
                </ul>
              </li>
              <li class="footer"><a href="#">Ver todos los mensajes</a></li>
            </ul>
          </li>
          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <span class="label label-warning">Acá ponga el número de notificaciones que va arriba</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"> coloque el numero de notificaciones acá</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                </ul>
              </li>
              <li class="footer"><a href="#">Ver todo</a></li>
            </ul>
          </li>
          <!-- Tasks: style can be found in dropdown.less -->
          <li class="dropdown tasks-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-flag-o"></i>
              <span class="label label-danger">Acá va el número de tareas que va arriba</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">Aquí van las tareas</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                </ul>
              </li>
              <li class="footer">
                <a href="#">Ver todas las tareas</a>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="assets/img/user8-128x128.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $_SESSION["user"]["nombres"]." ".$_SESSION["user"]["apellidos"]; ?>
              </span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="assets/img/user8-128x128.jpg" class="img-circle" alt="User Image">

                <p>
                 <?php echo $_SESSION["user"]["nombres"]." ".$_SESSION["user"]["apellidos"]; ?>
                  <small><?php  
                  if ($_SESSION['user']['roles_id_rol'] ==4) {
                echo "Administrador";
            }elseif ($_SESSION['user']['roles_id_rol']==3) {
                echo "Asesor Academico";
            }elseif ($_SESSION['user']['roles_id_rol'] ==2) {
                echo "Moderador";
            }elseif ($_SESSION['user']['roles_id_rol'] ==5) {
                echo "Jefe Institucional";
            }elseif ($_SESSION['user']['roles_id_rol'] ==1) {
                echo "Estudiante";
            }elseif ($_SESSION['user']['roles_id_rol'] ==0) {
                echo "Superadministrador";
            }?></small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Perfil</a>
                </div>
                <div class="pull-right">
                  <a href="?c=cliente&a=Index" class="btn btn-default btn-flat">Cerrar Sesión</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->

        </ul>
      </div>

    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="assets/img/user8-128x128.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $_SESSION["user"]["nombres"]." ".$_SESSION["user"]["apellidos"]; ?></p>
          <a><i class="fa fa-circle text-success"></i>
                  <small><?php  
                  if ($_SESSION['user']['roles_id_rol'] ==4) {
                echo "Administrador";
            }elseif ($_SESSION['user']['roles_id_rol']==3) {
                echo "Asesor Academico";
            }elseif ($_SESSION['user']['roles_id_rol'] ==2) {
                echo "Moderador";
            }elseif ($_SESSION['user']['roles_id_rol'] ==5) {
                echo "Jefe Institucional";
            }elseif ($_SESSION['user']['roles_id_rol'] ==1) {
                echo "Estudiante";
            }elseif ($_SESSION['user']['roles_id_rol'] ==0) {
                echo "Superadministrador";
            }?></small>
          </a>
        </div>
      </div>
    </section>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">NAVEGACION PRINCIPAL</li>
        <li><a href="?c=cliente&a=Entrada"><i class="fa fa-home "></i> <span>Inicio</span></a></li>
        <li><a href="?c=cliente&a=Inicio"><i class="fa fa-book"></i> <span>Asignación de Roles</span></a></li>
        <li><a href="?c=cliente&a=Procesos"><i class="fa fa-pie-chart"></i>  <span>Procesos</span></a></li>
        <li><a href="?c=cliente&a=Estudiantes"><i class="fa fa-hand-spock-o"></i> <span>Estudiantes</span></a></li>

  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Aplicativo Psicología
        <small>Version 0.1</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="?c=cliente&a=Entrada"><i class="fa fa-home"></i> Inicio</a></li>        
      </ol>
    </section>

 
<br>

<section class="content container-fluid">
   <!--opening slider -->
        <div class="swiper-container main-slider loading">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <figure class="slide-bgimg" >
              <img src="assets/img/photo3.jpg"width="100%" height="100%" position="fixed" />
            </figure>
            <div class="content">
              <p class="title">Shaun Matthews</p>
              <span class="caption1">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</span>
            </div>
          </div>
          <div class="swiper-slide">
            <figure class="slide-bgimg">
              <img src="assets/img/ucc.png"width="100%" height="100%"   />
            </figure>
            <div class="content">
              <p class="title">Alexis Berry</p>
              <span class="caption1">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</span>
            </div>
          </div>
          <div class="swiper-slide">
            <figure class="slide-bgimg" >
              <img src="assets/img/photo1.png"width="100%" height="100%"  />
            </figure>
            <div class="content">
              <p class="title">Billie Pierce</p>
              <span class="caption1">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</span>
            </div>
          </div>
          <div class="swiper-slide">
             <figure class="slide-bgimg" >
              <img src="assets/img/photo2.png"width="100%" height="100%" />
            </figure>
            <div class="content">
              <p class="title">Trevor Copeland</p>
              <span class="caption1">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</span>
            </div>
          </div>
          <div class="swiper-slide">
            <figure class="slide-bgimg" >
              <img src="assets/img/photo4.jpg" width="100%" height="100%" />
            </figure>
            <div class="content">
              <p class="title">Bernadette Newman</p>
              <span class="caption1">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</span>
            </div>
          </div>
        </div>
        <!-- If we need navigation buttons -->
        <div class="swiper-button-prev swiper-button-white"></div>
        <div class="swiper-button-next swiper-button-white"></div>
      </div>

      <!-- Thumbnail navigation -->
      <div class="swiper-container nav-slider loading">
        <div class="swiper-wrapper">
          <div class="swiper-slide">
            <figure class="slide-sllimg" >
              <img src="assets/img/photo3.jpg"width="100%" height="100%" />
            </figure>
            <div class="content">
              <p class="title">Shaun Matthews</p>
            </div>
          </div>
          <div class="swiper-slide">
            <figure class="slide-sllimg">
              <img src="assets/img/ucc.png" width="100%" height="100%" />
            </figure>
            <div class="content">
              <p class="title">Alexis Berry</p>
            </div>
          </div>
          <div class="swiper-slide">
            <figure class="slide-sllimg">
              <img src="assets/img/photo1.png"width="100%" height="100%" />
            </figure>
            <div class="content">
              <p class="title">Billie Pierce</p>
            </div>
          </div>
          <div class="swiper-slide">
            <figure class="slide-sllimg" >
              <img src="assets/img/photo2.png" width="100%" height="100%" />
            </figure>
            <div class="content">
              <p class="title">Trevor Copeland</p>
            </div>
          </div>
          <div class="swiper-slide">
            <figure class="slide-sllimg" >
              <img src="assets/img/photo4.jpg" width="100%"  height="100%"/>
            </figure>
            <div class="content">
              <p class="title">Bernadette Newman</p>
            </div>
          </div>
        </div>
      </div>
      <script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.0.7/js/swiper.min.js'></script>
      <script src="assets/js/slider.js" type="text/javascript"></script>
</section>
<!--ending slider -->

          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row 
    </section>
     /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.1
    </div>
    <strong>Copyright &copy; 2018 <a href="https://www.ucc.edu.co/">UCC</a>.</strong> Todos los derechos reservados.
  </footer>
        </form>
      </div>
    </div>
  </aside>
   <div class="control-sidebar-bg"></div>

</div>
<!-- Bootstrap 3.3.7 -->
<script src="assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="assets/js/adminlte.min.js"></script>
<!-- Sparkline -->
<script src="assets/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap  -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- SlimScroll -->
<script src="assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- ChartJS -->
<script src="assets/bower_components/chart.js/Chart.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="assets/js/demo.js"></script>
</body>
</html>
<?php 
}
else{
require_once 'views/error_acceso.html';
require_once 'views/index.html';
}
?>