<h1 class="page-header">
    <?php echo $cliente->id_usuario != null ? $cliente->nombres : 'Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <li><a href="?c=cliente">Usuario</a></li>
  <li class="active"><?php echo $cliente->id_usuario != null ? $cliente->nombres : 'Nuevo Registro'; ?></li>
</ol>

<form id="frm-alumno" action="?c=cliente&a=Guardar" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id_usuario" value="<?php echo $cliente->id_usuario; ?>" />
      
    
    <div class="form-group">
        <label>Nombre</label>
        <input type="text" name="nombres" value="<?php echo $cliente->nombres; ?>" class="form-control" placeholder="Ingrese su nombre" required>
    </div>
    
    <div class="form-group">
        <label>Apellido</label>
        <input type="text" name="apellidos" value="<?php echo $cliente->apellidos; ?>" class="form-control" placeholder="Ingrese su apellido" required>
    </div>
        <label>Tipo de documento</label>
          <select class="form-control" name="tipos_identificaciones_id_tipo"  required>
            <?php
        if ($cliente->tipos_identificaciones_id_tipo== "")  {
          echo"<option value='' selected>Tipo de documento</option>
        <option value='0'>1- Cédula de Ciudadania</option>
        <option value='1'>2- Cédula Extranjera</option>
        <option value='2'>3- Tarjeta de Identidad</option>
        <option value='3'>4- Pasaporte</option>";
        }elseif ($cliente->tipos_identificaciones_id_tipo== "0") {
           echo"<option value=''>Tipo de documento</option>
        <option value='0' selected>1- Cédula de Ciudadania</option>
        <option value='1'>2- Cédula Extranjera</option>
        <option value='2'>3- Tarjeta de Identidad</option>
        <option value='3'>4- Pasaporte</option>";
        }elseif($cliente->tipos_identificaciones_id_tipo== "1"){
        echo"<option value=''>Tipo de documento</option>
        <option value='0'>1- Cédula de Ciudadania</option>
        <option value='1' selected>2- Cédula Extranjera</option>
        <option value='2'>3- Tarjeta de Identidad</option>
        <option value='3'>4- Pasaporte</option>";}
        elseif($cliente->tipos_identificaciones_id_tipo== "2"){
        echo"<option value=''>Tipo de documento</option>
        <option value='0'>1- Cédula de Ciudadania</option>
        <option value='1' selected>2- Cédula Extranjera</option>
        <option value='2' selected>3- Tarjeta de Identidad</option>
        <option value='3'>4- Pasaporte</option>";}
        elseif($cliente->tipos_identificaciones_id_tipo== "3"){
        echo"<option value=''>Tipo de documento</option>
        <option value='0'>1- Cédula de Ciudadania</option>
        <option value='1' selected>2- Cédula Extranjera</option>
        <option value='2'>3- Tarjeta de Identidad</option>
        <option value='3' selected>4- Pasaporte</option>";}
       ?>
        
      </select>
      <br>
          <div class="form-group">
        <label>identificacion</label>
        <input type="text" name="identificacion" value="<?php echo $cliente->identificacion;?>" class="form-control" placeholder="Ingrese su cedula" required>
    </div>

    <div class="form-group">
        <label>Sexo</label>
      <select class="form-control" name="sexo"  required>
        <?php
        if ($cliente->sexo== "")  {
          echo"<option value='' selected>Seleccionar sexo</option>
          <option value='1'>1- Masculino</option>
          <option value='0'>2- Femenino</option>";
        }elseif ($cliente->sexo== 1) {
           echo"<option value=''>Seleccionar sexo</option>
          <option value='1' selected>1- Masculino</option>
          <option value='0'>2- Femenino</option>";
        }elseif($cliente->sexo== 0){
        echo"<option value=''>Seleccionar sexo</option>
          <option value='1'>1- Masculino</option>
          <option value='0' selected>2- Femenino</option>";}
       ?>
      </select>
    </div>
    <div class="form-group">
        <label>Correo</label>
        <input type="text" name="correo" value="<?php echo $cliente->correo; ?>" class="form-control" placeholder="Ingrese su correo electrónico" required>
    </div>
     <div class="form-group">
        <label>Telefono</label>
        <input type="text" name="telefono" value="<?php echo $cliente->telefono; ?>" class="form-control" placeholder="Ingrese su telefono" required>
    </div>
    <div class="form-group">
        <label>Dirección</label>
        <input type="text" name="direccion" value="<?php echo $cliente->direccion; ?>" class="form-control" placeholder="Ingrese su direccion" required>
    </div>

    <div class="form-group has-feedback">
        <label>Fecha de nacimiento</label>
        <input type="date" class="form-control" name="fecha_nacimiento" value="<?php echo $cliente->fecha_nacimiento; ?>" placeholder="" required="">
        
        <span class="glyphicon glyphicon-calendar form-control-feedback"></span>
      </div>
     <div class="form-group">
        <label>Clave</label>
        <input type="password" name="clave" value="<?php echo $cliente->clave; ?>" class="form-control" placeholder="Ingrese la clave" required>
    </div>
        
     <div class="form-group">
        <label>EPS</label>
        <input type="text" name="eps" value="<?php echo $cliente->eps; ?>" class="form-control" placeholder="Ingrese su EPS" required>
    </div>
     <div class="form-group">
        <label>Rol al que aplica</label>
        <select class="form-control" name="solicitud"required>
            <?php
        if ($cliente->solicitud== "")  {
          echo"<option value='' selected>Seleccionar cargo</option>
        <option value='5'>1- Estudiante</option>
        <option value='3'>2- Moderador</option>
        <option value='2'>3- Asesor Academico</option>
        <option value='1'>4- Administrador</option>
        <option value='4'>5- Jefe Institucional</option>";
        }elseif ($cliente->solicitud== "0") {
           echo"        <option value=''>Seleccionar cargo</option>
        <option value='5'>1- Estudiante</option>
        <option value='3'>2- Moderador</option>
        <option value='2'>3- Asesor Academico</option>
        <option value='1'>4- Administrador</option>
        <option value='4'>5- Jefe Institucional</option>";
        }elseif($cliente->solicitud== "1"){
        echo"        <option value=''>Seleccionar cargo</option>
        <option value='5'>1- Estudiante</option>
        <option value='3'>2- Moderador</option>
        <option value='2'>3- Asesor Academico</option>
        <option value='1' selected>4- Administrador</option>
        <option value='4'>5- Jefe Institucional</option>";}
        elseif($cliente->solicitud== "2"){
        echo"        <option value=''>Seleccionar cargo</option>
        <option value='5'>1- Estudiante</option>
        <option value='3'>2- Moderador</option>
        <option value='2' selected>3- Asesor Academico</option>
        <option value='1'>4- Administrador</option>
        <option value='4'>5- Jefe Institucional</option>";}
        elseif($cliente->solicitud== "3"){
        echo"        <option value=''>Seleccionar cargo</option>
        <option value='5'>1- Estudiante</option>
        <option value='3' selected>2- Moderador</option>
        <option value='2'>3- Asesor Academico</option>
        <option value='1'>4- Administrador</option>
        <option value='4'>5- Jefe Institucional</option>";}
        elseif($cliente->solicitud== "4"){
        echo"        <option value=''>Seleccionar cargo</option>
        <option value='5'>1- Estudiante</option>
        <option value='3'>2- Moderador</option>
        <option value='2'>3- Asesor Academico</option>
        <option value='1'>4- Administrador</option>
        <option value='4' selected>5- Jefe Institucional</option>";}
        elseif($cliente->solicitud== "5"){
        echo"        <option value=''>Seleccionar cargo</option>
        <option value='5'  selected>1- Estudiante</option>
        <option value='3'>2- Moderador</option>
        <option value='2'>3- Asesor Academico</option>
        <option value='1'>4- Administrador</option>
        <option value='4'>5- Jefe Institucional</option>";}
       ?>

      </select>
    </div>    
     <div class="form-group">
        <label>Estado</label>
        <select class="form-control" name="estado"  required>
                    <?php
        if ($cliente->estado== "")  {
          echo"<option value='' selected>Seleccionar Estado</option>
          <option value='1'>1- Activo</option>
          <option value='0'>2- Inactivo</option>";
        }elseif ($cliente->estado== "1") {
           echo"<option value=''>Seleccionar Estado</option>
          <option value='1'  selected>1- Activo</option>
          <option value='0'>2- Inactivo</option>";
        }elseif($cliente->estado== "0"){
        echo"<option value=''>Seleccionar Estado</option>
          <option value='1'>1- Activo</option>
          <option value='0' selected>2- Inactivo</option>";}
       ?>

      </select>
    </div>
    <div class="text-right">
        <button class="btn btn-primary">Guardar</button>
    </div></div></div><hr />
</form>

<script>
    $(document).ready(function(){
        $("#frm-alumno").submit(function(){
            return $(this).validate();
        });
    })
</script>