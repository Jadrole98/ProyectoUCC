<?php
    if(!isset($_SESSION)) 
    { 
        session_start(); 
    } 
?>
<?php 
error_reporting(E_ALL ^ E_NOTICE);
if ($_SESSION["autenticado"]==true) {
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Aplicativo | Página de inicio</title>

  <!-- Tell the browser to be responsive to screen width -->
  <link rel="shortcut icon" href="assets/img/logo.ico" type="image/x-icon" />
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="assets/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="assets/bower_components/Ionicons/css/ionicons.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="assets/bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="assets/css/AdminLTE.min.css">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
  <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css" />
  <link rel="stylesheet" href="assets/js/jquery-ui/jquery-ui.min.css" />
  <link rel="stylesheet" href="assets/css/style.css" />
  <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
  <script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
  <script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
  <link rel="stylesheet" href="assets/css/skins/_all-skins.min.css">

</head>
<style>
   body
   {
    margin:0;
    padding:0;
    background-color:#f1f1f1;
   }
   .box
   {
    padding:20px;
    background-color:#fff;
    border:1px solid #ccc;
    border-radius:5px;
    margin-top:25px;
   }
  </style>
  </head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">

    <!-- Logo -->
    <a href="?c=cliente&a=Entrada" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>P</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg">Aplicativo Psicología</span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-envelope-o"></i>
              <span class="label label-success">Aquí el numero que sale arriba de los mensajes</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"> coloque el numero de mensajes que tiene</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                  </li>
                </ul>
              </li>
              <li class="footer"><a href="#">Ver todos los mensajes</a></li>
            </ul>
          </li>
          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <span class="label label-warning">Acá ponga el número de notificaciones que va arriba</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"> coloque el numero de notificaciones acá</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                </ul>
              </li>
              <li class="footer"><a href="#">Ver todo</a></li>
            </ul>
          </li>
          <!-- Tasks: style can be found in dropdown.less -->
          <li class="dropdown tasks-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-flag-o"></i>
              <span class="label label-danger">Acá va el número de tareas que va arriba</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">Aquí van las tareas</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                </ul>
              </li>
              <li class="footer">
                <a href="#">Ver todas las tareas</a>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="assets/img/user8-128x128.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs"> <?php echo $_SESSION["user"]["nombres"]." ".$_SESSION["user"]["apellidos"]; ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
               <img src="assets/img/user8-128x128.jpg" class="img-circle" alt="User Image">

                <p>
                 <?php echo $_SESSION["user"]["nombres"]." ".$_SESSION["user"]["apellidos"]; ?>
                  <small><?php  
                  if ($_SESSION['user']['roles_id_rol'] ==4) {
                echo "Administrador";
            }elseif ($_SESSION['user']['roles_id_rol']==3) {
                echo "Asesor Academico";
            }elseif ($_SESSION['user']['roles_id_rol'] ==2) {
                echo "Moderador";
            }elseif ($_SESSION['user']['roles_id_rol'] ==5) {
                echo "Jefe Institucional";
            }elseif ($_SESSION['user']['roles_id_rol'] ==1) {
                echo "Estudiante";
            }elseif ($_SESSION['user']['roles_id_rol'] ==0) {
                echo "Superadministrador";
            }?></small>
                </p>
              </li>
              <!-- Menu Body -->
              <li class="user-body">
                <div class="row">
                  <div class="col-xs-4 text-center">
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Perfil</a>
                </div>
                <div class="pull-right">
                  <a href="?c=cliente&a=Index" class="btn btn-default btn-flat">Cerrar Sesión</a>
                </div>
              </li>
            </ul>
          </li>

        </ul>
      </div>

    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
<section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="assets/img/user8-128x128.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $_SESSION["user"]["nombres"]." ".$_SESSION["user"]["apellidos"]; ?></p>
          <a><i class="fa fa-circle text-success"></i>
                  <small><?php  
                  if ($_SESSION['user']['roles_id_rol'] ==4) {
                echo "Administrador";
            }elseif ($_SESSION['user']['roles_id_rol']==3) {
                echo "Asesor Academico";
            }elseif ($_SESSION['user']['roles_id_rol'] ==2) {
                echo "Moderador";
            }elseif ($_SESSION['user']['roles_id_rol'] ==5) {
                echo "Jefe Institucional";
            }elseif ($_SESSION['user']['roles_id_rol'] ==1) {
                echo "Estudiante";
            }elseif ($_SESSION['user']['roles_id_rol'] ==0) {
                echo "Superadministrador";
            }?></small>
          </a>
        </div>
      </div>
    </section>
    
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">NAVEGACION PRINCIPAL</li>
        <li><a href="?c=cliente&a=Entrada"><i class="fa fa-home"></i> <span>Inicio</span></a></li>
        <li><a href="?c=cliente&a=Inicio"><i class="fa fa-book"></i> <span>Asignación de Roles</span></a></li>
        <li><a href="?c=cliente&a=Procesos"><i class="fa fa-pie-chart"></i>  <span>Procesos</span></a></li>
        <li><a href="?c=cliente&a=Estudiantes"><i class="fa fa-hand-spock-o"></i> <span>Estudiantes</span></a></li>>
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Aplicativo Psicología
        <small>Version 0.1</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="?c=cliente&a=Entrada"><i class="fa fa-home"></i> Inicio</a></li>
        <li class="active">Asignación de Roles</li>  
      </ol>
    </section>

 <section class="content container-fluid">
<br>
<div class="login-box-body">

 <h3 class="box-title">Administrativos</h3>
<div class="box box-danger">                
               


<h1 class="page-header">
    <?php echo $cliente->id_usuario != null ? $cliente->nombres : 'Nuevo Registro'; ?>
</h1>

<ol class="breadcrumb">
  <li><a href="?c=cliente">Usuario</a></li>
  <li class="active"><?php echo $cliente->id_usuario != null ? $cliente->nombres : 'Nuevo Registro'; ?></li>
</ol>

<form action="?c=cliente&a=Guardar" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id_usuario" value="<?php echo $cliente->id_usuario; ?>" />
      
    
    <div class="form-group">
        <label>Nombre</label>
        <input type="text" name="nombres" value="<?php echo $cliente->nombres; ?>" class="form-control" placeholder="Ingrese su nombre" required>
    </div>
    
    <div class="form-group">
        <label>Apellido</label>
        <input type="text" name="apellidos" value="<?php echo $cliente->apellidos; ?>" class="form-control" placeholder="Ingrese su apellido" required>
    </div>
        <label>Tipo de documento</label>
          <select class="form-control" name="tipos_identificaciones_id_tipo"  required>
            <?php
        if ($cliente->tipos_identificaciones_id_tipo== "")  {
          echo"<option value='' selected>Tipo de documento</option>
        <option value='1'>1- Cédula de Ciudadania</option>
        <option value='2'>2- Cédula Extranjera</option>
        <option value='3'>3- Tarjeta de Identidad</option>
        <option value='4'>4- Pasaporte</option>";
        }elseif ($cliente->tipos_identificaciones_id_tipo== "0") {
           echo"<option value=''>Tipo de documento</option>
        <option value='1' selected>1- Cédula de Ciudadania</option>
        <option value='2'>2- Cédula Extranjera</option>
        <option value='3'>3- Tarjeta de Identidad</option>
        <option value='4'>4- Pasaporte</option>";
        }elseif($cliente->tipos_identificaciones_id_tipo== "1"){
        echo"<option value=''>Tipo de documento</option>
        <option value='1'>1- Cédula de Ciudadania</option>
        <option value='2' selected>2- Cédula Extranjera</option>
        <option value='3'>3- Tarjeta de Identidad</option>
        <option value='4'>4- Pasaporte</option>";}
        elseif($cliente->tipos_identificaciones_id_tipo== "2"){
        echo"<option value=''>Tipo de documento</option>
        <option value='1'>1- Cédula de Ciudadania</option>
        <option value='2' >2- Cédula Extranjera</option>
        <option value='3' selected>3- Tarjeta de Identidad</option>
        <option value='4'>4- Pasaporte</option>";}
        elseif($cliente->tipos_identificaciones_id_tipo== "3"){
        echo"<option value=''>Tipo de documento</option>
        <option value='1'>1- Cédula de Ciudadania</option>
        <option value='2'>2- Cédula Extranjera</option>
        <option value='3'>3- Tarjeta de Identidad</option>
        <option value='4' selected>4- Pasaporte</option>";}
       ?>
        
      </select>
      <br>
          <div class="form-group">
        <label>identificacion</label>
        <input type="text" name="identificacion" value="<?php echo $cliente->identificacion;?>" class="form-control" placeholder="Ingrese su cedula" required>
    </div>

    <div class="form-group">
        <label>Sexo</label>
      <select class="form-control" name="sexo"  required>
        <?php
        if ($cliente->sexo== "")  {
          echo"<option value='' selected>Seleccionar sexo</option>
          <option value='1'>1- Masculino</option>
          <option value='0'>2- Femenino</option>";
        }elseif ($cliente->sexo== 1) {
           echo"<option value=''>Seleccionar sexo</option>
          <option value='1' selected>1- Masculino</option>
          <option value='0'>2- Femenino</option>";
        }elseif($cliente->sexo== 0){
        echo"<option value=''>Seleccionar sexo</option>
          <option value='1'>1- Masculino</option>
          <option value='0' selected>2- Femenino</option>";}
       ?>
      </select>
    </div>
    <div class="form-group">
        <label>Correo</label>
        <?php echo $cliente->id_usuario != null ? "<input type='text' name='correo' value=' $cliente->correo' class='form-control' placeholder='Ingrese su correo electrónico' required readonly='readonly'>" : '<input type="text" name="correo" value="" class="form-control" placeholder="Ingrese su correo electrónico" required ">'; ?>
        
    </div>
     <div class="form-group">
        <label>Telefono</label>
        <input type="text" name="telefono" value="<?php echo $cliente->telefono; ?>" class="form-control" placeholder="Ingrese su telefono" required>
    </div>
    <div class="form-group">
        <label>Dirección</label>
        <input type="text" name="direccion" value="<?php echo $cliente->direccion; ?>" class="form-control" placeholder="Ingrese su direccion" required>
    </div>

    <div class="form-group has-feedback">
        <label>Fecha de nacimiento</label>
        <input type="date" class="form-control" name="fecha_nacimiento" value="<?php echo $cliente->fecha_nacimiento; ?>" placeholder="" required="">
        
        <span class="glyphicon glyphicon-calendar form-control-feedback"></span>
      </div>
     <div class="form-group">
        <label>Clave</label>
        <input type="password" name="clave" value="<?php echo $cliente->clave; ?>" class="form-control" placeholder="Ingrese la clave" required>
    </div>
        
     <div class="form-group">
        <label>EPS</label>
        <input type="text" name="eps" value="<?php echo $cliente->eps; ?>" class="form-control" placeholder="Ingrese su EPS" required>
    </div>
     <div class="form-group">
        <label>Rol al que aplica</label>
        <select class="form-control" name="solicitud"required>
            <?php
        if ($cliente->solicitud== "")  {
          echo"<option value='' selected>Seleccionar cargo</option>
        <option value='1'>1- Estudiante</option>
        <option value='2'>2- Moderador</option>
        <option value='3'>3- Asesor Academico</option>
        <option value='4'>4- Administrador</option>
        <option value='5'>5- Jefe Institucional</option>";
        }elseif ($cliente->solicitud== "0") {
           echo"        <option value=''>Seleccionar cargo</option>
        <option value='1'>1- Estudiante</option>
        <option value='2'>2- Moderador</option>
        <option value='3'>3- Asesor Academico</option>
        <option value='4'>4- Administrador</option>
        <option value='5'>5- Jefe Institucional</option>";
        }elseif($cliente->solicitud== "1"){
        echo"        <option value=''>Seleccionar cargo</option>
        <option value='1'>1- Estudiante</option>
        <option value='2'>2- Moderador</option>
        <option value='3'>3- Asesor Academico</option>
        <option value='4' selected>4- Administrador</option>
        <option value='5'>5- Jefe Institucional</option>";}
        elseif($cliente->solicitud== "2"){
        echo"        <option value=''>Seleccionar cargo</option>
        <option value='1'>1- Estudiante</option>
        <option value='2'>2- Moderador</option>
        <option value='3' selected>3- Asesor Academico</option>
        <option value='4'>4- Administrador</option>
        <option value='5'>5- Jefe Institucional</option>";}
        elseif($cliente->solicitud== "3"){
        echo"        <option value=''>Seleccionar cargo</option>
        <option value='1'>1- Estudiante</option>
        <option value='2' selected>2- Moderador</option>
        <option value='3'>3- Asesor Academico</option>
        <option value='4'>4- Administrador</option>
        <option value='5'>5- Jefe Institucional</option>";}
        elseif($cliente->solicitud== "4"){
        echo"        <option value=''>Seleccionar cargo</option>
        <option value='1'>1- Estudiante</option>
        <option value='2'>2- Moderador</option>
        <option value='3'>3- Asesor Academico</option>
        <option value='4'>4- Administrador</option>
        <option value='5' selected>5- Jefe Institucional</option>";}
        elseif($cliente->solicitud== "5"){
        echo"        <option value=''>Seleccionar cargo</option>
        <option value='1'  selected>1- Estudiante</option>
        <option value='2'>2- Moderador</option>
        <option value='3'>3- Asesor Academico</option>
        <option value='4'>4- Administrador</option>
        <option value='5'>5- Jefe Institucional</option>";}
       ?>

      </select>
    </div>    
     <div class="form-group">
        <label>Estado</label>
        <select class="form-control" name="estado"  required>
                    <?php
        if ($cliente->estado== "")  {
          echo"<option value='' selected>Seleccionar Estado</option>
          <option value='1'>1- Activo</option>
          <option value='0'>2- Inactivo</option>";
        }elseif ($cliente->estado== "1") {
           echo"<option value=''>Seleccionar Estado</option>
          <option value='1'  selected>1- Activo</option>
          <option value='0'>2- Inactivo</option>";
        }elseif($cliente->estado== "0"){
        echo"<option value=''>Seleccionar Estado</option>
          <option value='1'>1- Activo</option>
          <option value='0' selected>2- Inactivo</option>";}
       ?>

      </select>
    </div>
     <input type="hidden" name="roles_id_rol" value="20" />
    <div class="text-right">
        <button class="btn btn-primary">Guardar</button>
    
</form>
</section>
<script>
    $(document).ready(function(){
        $("#frm-alumno").submit(function(){
            return $(this).validate();
        });
    })
</script>

          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row 
    </section>
     /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.1
    </div>
    <strong>Copyright &copy; 2018 <a href="https://www.ucc.edu.co/">UCC</a>.</strong> Todos los derechos reservados.
  </footer>
        </form>
      </div>
    </div>
  </aside>
   <div class="control-sidebar-bg"></div>

</div>

<script src="assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="assets/js/adminlte.min.js"></script>
<!-- Sparkline -->
<script src="assets/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap  -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- SlimScroll -->
<script src="assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- ChartJS -->
<script src="assets/bower_components/chart.js/Chart.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="assets/js/pages/dashboard2.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="assets/js/demo.js"></script>
</body>
</html>
<?php 
}
else{
require_once 'views/error_acceso.html';
require_once 'views/index.html';
}