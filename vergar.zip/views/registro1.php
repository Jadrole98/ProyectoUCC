<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
        <link rel="shortcut icon" href="assets/img/logo.ico" type="image/x-icon" />
        <link rel="stylesheet" href="assets/css/bootstrap.min.css" />
        <link rel="stylesheet" href="assets/css/bootstrap-theme.min.css" />
        <link rel="stylesheet" href="assets/js/jquery-ui/jquery-ui.min.css" />
        <link rel="stylesheet" href="assets/css/style.css" />
        <link href="plugins/datatables/dataTables.bootstrap.css" rel="stylesheet" type="text/css" />
        
        <script src="http://code.jquery.com/jquery-1.11.2.min.js"></script>
         <script src="plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Aplicativo | Pagina de Registro</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="assets/bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="assets/bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="assets/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">
  
</head>
<body class="hold-transition register-page" style="background-color:#242E3D;">
<div class="register-box">
  <div class="login-box">
<center>
<img src="assets/img/ucc.png" style="width: 50%" >
</center> 
  <div class="login-logo"> 

    <font face="norwester" color="white">PSICOLOGIA UCC </font>

    <!--   -->
  </div>

  <div class="register-box-body">
    <p class="login-box-msg">Registrar Nuevo Entidad Empresarial</p>

    <form id="frm-alumno" action="?c=cliente&a=Guardar1" method="post" enctype="multipart/form-data">
      <div class="form-group has-feedback">
         <input type="hidden" name="id_usuario" value="<?php echo $cliente->id_usuario; ?>" />
        <input type="text" class="form-control"  name="nombres" placeholder="nombres"  required>
        <span class="glyphicon glyphicon-user form-control-feedback" ></span>
      </div>
      <div class="form-group has-feedback">
        <input type="text" class="form-control"  name="apellidos" placeholder="Apellidos" required>
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
      </div>
      <select class="form-control" name="tipos_identificaciones_id_tipo"  required>
        <option value="">Tipo de documento</option>
        <option value="1">1- Cédula de Ciudadania</option>
        <option value="2">2- Cédula Extranjera</option>
        <option value="3">3- Tarjeta de Identidad</option>
        <option value="4">4- Pasaporte</option>
      </select>
      </br>
      <div class="form-group has-feedback">
        <input type="text" class="form-control"  name="identificacion" placeholder="Identificacion" required>
        <span class="glyphicon glyphicon-credit-card form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="text" class="form-control"  name="direccion" placeholder="Direccion" required>
        <span class="glyphicon glyphicon-home form-control-feedback"></span>        
      </div>
      <div class="form-group has-feedback">
        <input type="text" class="form-control"  name="eps" placeholder="Eps" required>
        <span class="glyphicon glyphicon-plus-sign form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="email" class="form-control"  name="correo" placeholder="Correo" required">
        <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="text" class="form-control"  name="telefono" placeholder="Telefono" required>
        <span class="glyphicon glyphicon-phone form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control"  name="clave" placeholder="Clave" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>  

      <div class="form-group has-feedback">
        <input type="date" class="form-control" name="fecha_nacimiento"  placeholder="Fecha de nacimiento" required>
        
        <span class="glyphicon glyphicon-calendar form-control-feedback"></span>
      </div>
      <input type="hidden" name="solicitud" value="4" />
      <select class="form-control" name="sexo"  required>
        <option value="">Seleccionar sexo</option>
        <option value="1">1- Masculino</option>
        <option value="0">2- Femenino</option>
       
      </select>
      <input type="hidden" name="estado" value="1" />
      <input type="hidden" name="roles_id_rol" value="20" />
      </br>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox" required> Acepto <a href="#">Terminos y Condiciones</a>
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button class="btn btn-primary">Registrar</button>
        </div>
        <!-- /.col -->
      </div>
    </form>
    <script>
    $(document).ready(function(){
        $("#frm-alumno").submit(function(){
            return $(this).validate();
        });
    })
</script>
  <a href="index.php" class="text-center">Actualmente estoy registrado</a>

  </div>
  <!-- /.form-box -->
</div>
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' /* optional */
    });
  });
</script>
</body>
</html>
